# Security Policy

## Reporting a Vulnerability

Please send all POCs to security[at]osticket[dot]com.
