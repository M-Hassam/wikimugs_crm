<div id="task_content">
<?php
require STAFFINC_DIR.'templates/task-view.tmpl.php';
?>
</div>
